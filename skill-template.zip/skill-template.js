// Print a debug message
misty.Debug("Hello, world!")
// Change Misty's chest LED to green
misty.ChangeLED(0, 255, 0);
// Pause for one second
misty.Pause(1000);
// Change Misty's LED to red
misty.ChangeLED(255, 0, 0);